const demos = [
    {
        id: 1,
        name: "Shape",
        file: "ShapeDemo",
    },
    {
        id: 2,
        name: "Color",
        file: "ColorDemo",
    },
    {
        id: 3,
        name: "Size",
        file: "SizeDemo",
    },
];

export default demos;
